<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editdeaorder?id=').$before1; ?>">Store Order Details</a></li>
<li><a href="<?php echo site_url('site/vieworderproduct?id=').$before2; ?>">Ordered Products</a></li>
</ul>
</div>
</section>
