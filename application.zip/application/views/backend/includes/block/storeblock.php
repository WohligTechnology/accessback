<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editstore?id=').$before1; ?>">Store Details</a></li>
<li><a href="<?php echo site_url('site/viewstoreprice?id=').$before2; ?>">Store Price</a></li>
</ul>
</div>
</section>
