HEllo
<!--<img src="<?php base_url('../img/logo.jpg';?>">-->
<div class='header' style='width:100%;float:left;border-bottom:1px solid #000;'>
	<img src="<?php echo base_url('../img/logo.jpg'); ?>" style='padding-bottom:10px;float:right;'>
</div>
<div class='address-container' style="width: 100%;padding: 1% 0;float: left;">
		<span class='address' style='width:100%;font-size:8px;font-family: century gothic;'>Suite 59B,4th Floor,Stephen House,B.B.D. Bag,56E Hemanta Basu Sarani,Kolkata 700001,Landline:+91 33 4005 4587, e-mail:info@taxassist.in, Website:www.taxassist.in</span>
	</div>
HELLO

	